package com.interfaces.fileoperation;

public interface FileOperation {
	public abstract void processFile();

}
